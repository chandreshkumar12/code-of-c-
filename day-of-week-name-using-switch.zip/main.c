/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{int sun=1,mon=2,tue=3,wed=4,thu=5,fri=6,sat=7;
switch(sun){
  case 1:  printf("sunday\n");
   case 2:  printf("mon\n");
   case 3:  printf("tue\n");
    case 4:  printf("wed\n");
    case 5:  printf("thur\n");
   case 6: printf("fri\n");
    case 7:  printf("sat\n");
  
}
    return 0;
}