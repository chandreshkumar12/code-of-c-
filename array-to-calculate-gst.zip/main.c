/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{ float price [3];
printf("enter price ");

 scanf("%f",&price[0]);
 scanf("%f",&price[1]);
 scanf("%f",&price[2]);
 
 printf("total price 1 :%f\n",price[0]+(0.18*price[0]));
 printf("total price 2 :%f\n",price[1]+(0.18*price[1]));
  printf("total price 3 :%f\n",price[2]+(0.18*price[2]));
    return 0;
}
