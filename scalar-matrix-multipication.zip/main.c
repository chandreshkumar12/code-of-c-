/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int row,col,a[2][2],n;
printf("scalar matrix multiplication\n");
printf("enter the elements in matrix ");
for(row=0;row<2;row++){
    for(col=0;col<2;col++){
        
        scanf("%d",&a[row][col]);
    }
    
}
for(row=0;row<2;row++){
    for(col=0;col<2;col++){
        
        printf("%d",a[row][col]);
    }
    printf("\n");
    
}
printf("enter any num to multiply with matrix ");
scanf("%d",&n);
for(row=0;row<2;row++){
    for(col=0;col<2;col++){
        
        a[row][col]=n*a[row][col];
        
    }
    
}
printf(" resultant matrix ");
for(row=0;row<2;row++){
    for(col=0;col<2;col++){
        
        printf("%d ",a[row][col]);
    }
    printf("\n");
}

    
    return 0;
}
