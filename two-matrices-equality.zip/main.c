/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int a[2][2],b[2][2],i,j,result=0;
   printf("enter the elements  of matrix A ");
   
   for(i=0;i<2;i++){
       
      for(j=0;j<2;j++){
      scanf("%d",&a[i][j]);
      }
   }
   printf("matrix elements:  ");
    for(i=0;i<2;i++){
       
      for(j=0;j<2;j++){
      printf("%d ",a[i][j]);
      }
      printf("\n");
   }
    printf("enter the elements  of matrix b ");
   
   for(i=0;i<2;i++){
       
      for(j=0;j<2;j++){
      scanf("%d",&b[i][j]);
      }
   }
   printf("matrix elements:  ");
    for(i=0;i<2;i++){
       
      for(j=0;j<2;j++){
      printf("%d ",b[i][j]);
      }
      printf("\n");
   }
   for(i=0;i<2;i++){
       for(j=0;j<2;j++)
       {
           
          if (a[i][j]!=b[i][j]) 
          result=1;
       }
   }
   if(result==1)
         printf("both are equal");
   else
   printf("not equal");
    return 0;
}
