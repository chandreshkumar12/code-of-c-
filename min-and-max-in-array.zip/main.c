/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{int a[100],n,i,max,min;
printf("enter a size of array  ");
scanf("%d",&n);
printf("enter the element in array ");
 for(i=0;i<n;i++){
     scanf("%d",&a[i]);
 }
 min=max=a[0];
  for(i=0;i<n;i++){
      if(max<a[i])
	    max=a[i];
	    else if(min>a[i]){
	    min=a[i];}
  }
	    printf("maximum element in array is %d\n",max);
 printf("minimum element in arry is %d",min);
 
   

    return 0;
}
