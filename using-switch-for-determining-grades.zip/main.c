/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int g;
printf("enter a num ");
scanf("%d",&g);
switch(g>70&&g<80){
 case 1:printf("grade is C");
 break;
case 0:switch(g>80&&g<90){
    case 1:printf("grade is A");
    default:printf("no grade");
}}


    return 0;
    
}
    

