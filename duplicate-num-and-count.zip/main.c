/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{int a[100],n,i,flag=0,j,temp;
printf("enter the size of std::array");
scanf("%d",&n);
printf("enter the element in arry");
for(i=0;i<n;i++){
    scanf("%d",&a[i]);
    
}
//[2,3,4,2]----->2
 for(i=0;i<n;i++){
     for(j=i+1;j<n;j++){
        if(a[i]==a[j]){
            flag=1; // 1->true, 0-> false
            temp=a[i]=a[j];
            printf("\n dupicate no. found at position %d and %d and num is %d ",i,j,temp);
        } 
         
     }
 }   
if(flag==0){
    printf("\n array has no duplicate values ");
}



    return 0;
}
