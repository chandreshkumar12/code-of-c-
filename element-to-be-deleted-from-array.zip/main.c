/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int a[100],b[100],n,i,j,pos;
   printf("enter a size of array a");
   scanf("%d",&n);
   printf("enter elements of array");
   for(i=0;i<n;i++){
       scanf("%d",&a[i]);
   }
printf("enter an element to be deleted ");
   scanf("%d",&pos);
   for(i=pos;i<n-1;i++){
       a[i]=a[i+1];
       n--;
       for(i=0;i<n;i++){
        printf("%d",a[i]);   
           
   }
   }
       
       
       
       
   
    return 0;
}
