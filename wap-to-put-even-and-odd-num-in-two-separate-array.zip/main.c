/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int a[100],even[100],odd[100],i,e=0,o=0,n;
scanf("%d",&n);
for(i=0;i<n;i++){
 printf("%d value of array ",i);
scanf("%d",&a[i]);    
}
for(i=0;i<n;i++){
    if(a[i]%2==0){
even[e]=a[i];        
    e++;
}
    else{
    odd[o]=a[i];
    o++;
}
    
}
for(i=0;i<e;i++){
printf("%d",even[i]);
printf("\n");
for(i=0;i<o;i++)
printf("%d",odd[i]);
    
}



    return 0;
}
