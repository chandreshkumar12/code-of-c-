/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{ int num,index=0;
printf("enter a num ");
scanf("%d",&num);
do{
    printf("%d\n",index+1);
    index=index+1;
    
    
}while(index<num);


    return 0;
}

