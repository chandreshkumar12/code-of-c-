/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int a[20],n,i,j,temp;
printf("enter size  of element in array  ");
scanf("%d",&n);
printf("enter the element in array\n");
for(i=0;i<n;i++){
    scanf("%d",&a[i]);
}
for(i=0;i<n-1;i++){   //passes
    for(j=0;j<n-1-i;j++){  //comparison
        if(a[j]>a[j+1]){
            temp=a[j];
            a[j]=a[j+1];
            a[j+1]=temp;
            
        }
    }
}
    printf("sorted element are");
    for(i=0;i<n;i++){
    printf("%d\n",a[i]);
    }
    

    
    
    
    
    
    
    
    
    
    
    return 0;
}
