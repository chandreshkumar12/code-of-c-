/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{ int x,y;
  printf(" value of x and y: ");
    scanf("%d%d",&x,&y);
if(x>0&&y>0)
printf(" first quadrant");
else if(x<0&&y>0)
printf("second quadrant");
else if(x<0&&y<0)
printf("third quadrant");
else if(x>0&&y<0)
printf("fourth quadrant");



    return 0;
}
