/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int a[20][20],i,j,sum,n;
printf("enter the row and column to be printed ");
scanf("%d",&n);

printf("enter the element in matrix ");
for(i=0;i<n;i++){
      for(j=0;j<n;j++){
          scanf("%d",&a[i][j]);
  }
}
   for(i=0;i<n;i++){
      for(j=0;j<n;j++){
          printf("%d  ",a[i][j]);
  }
   printf("\n");  
   }
for(i=0;i<n;i++){
    sum=0;
  for(j=0;j<n;j++){
   sum=sum+a[i][j]; 
  }
  printf("sum of row %d is %d\n",i+1,sum);
}
for(i=0;i<n;i++){
    sum=0;
  for(j=0;j<n;j++){
   sum=sum+a[j][i]; 
  }
  printf("sum of column %d is %d\n",i+1,sum);
}

    return 0;
}
