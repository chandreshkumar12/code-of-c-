/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a[3][3],i,j,sum=0;
   for(i=0;i<3;i++){
   for(j=0;j<3;j++){
      scanf("%d",&a[i][j]);
   }
       
   
sum=sum+a[i][i];
}
printf("%d",sum);

    return 0;
}
