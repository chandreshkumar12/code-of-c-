/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main(){
    int grade;
printf("enter a num ");
scanf("%d",&grade);
if (grade>70&&grade<=80){
    printf("grasde is d");
}
else if(grade>80&&grade<90){
    printf("grade is a");
}
else {printf("no grade");   
    return 0;
}}
